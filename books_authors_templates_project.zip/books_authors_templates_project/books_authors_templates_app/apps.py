from django.apps import AppConfig


class BooksAuthorsTemplatesAppConfig(AppConfig):
    name = 'books_authors_templates_app'
