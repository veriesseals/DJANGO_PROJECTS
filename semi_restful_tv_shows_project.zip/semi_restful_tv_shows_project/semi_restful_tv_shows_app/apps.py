from django.apps import AppConfig


class SemiRestfulTvShowsAppConfig(AppConfig):
    name = 'semi_restful_tv_shows_app'
