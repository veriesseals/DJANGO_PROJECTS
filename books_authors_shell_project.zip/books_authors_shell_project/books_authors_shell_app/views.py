from django.shortcuts import render, HttpResponse, redirect

# Create your views here.

# -------------------------------------------------------------------|
# initial

def index (request):
    return HttpResponse ('Booyahhhhhh Again')
