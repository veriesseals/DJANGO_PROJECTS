from django.apps import AppConfig


class BookAuthorsShellAppConfig(AppConfig):
    name = 'book_authors_shell_app'
